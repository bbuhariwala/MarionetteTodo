var Marionette = require('backbone.marionette');
var SuccessAlertView = require("./successAlert");
var FailureAlertView = require("./failureAlert");
var CompleteSuccess = require("./modalView");
var ToDo = Marionette.LayoutView.extend({
	tagName: 'tr',
	template: require("../templates/todoitem.html"),
	events: {
		'click .assignee': 'handleEditAssignee',
		'click .saveAssignee': 'handleSaveAssignee',
		'click .undoAssignee': 'handleUndoAssignee',
		'click .text': 'handleEditText',
		'click .saveText': 'handleSaveText',
		'click .undoText': 'handleUndoText',
		'change .todoStatus' :  'handleCompletionStatus'
	},
	handleEditAssignee: function(){
		this.val = this.$el.find('.assigneeD').text();
		this.$el.find('.assigneeD').attr('contenteditable','true').focus();
	},
	handleSaveAssignee: function() {
		var current = this.$el.find('.assigneeD').text();
		var old = this.val;
		var attrib = this.$el.find('.assigneeD').attr('contenteditable');
		this.$el.find('.assigneeD').attr('contenteditable','false');
		if(current !== old && attrib === 'true'){
			var successAlertView = new SuccessAlertView({alertMessage:"TODO Assignee Updated & Saved Successfully!"});
			successAlertView.render();
		}
		else{
			var failureAlertView = new FailureAlertView({alertMessage:"Nothing to Save!"});
			failureAlertView.render();
		}
	},
	handleUndoAssignee: function() {
		var current = this.$el.find('.assigneeD').text();
		var old = this.val;
		var attrib = this.$el.find('.assigneeD').attr('contenteditable');
		this.$el.find('.assigneeD').attr('contenteditable','false');
		if(current !== old && attrib === 'true'){
			this.$el.find('.assigneeD').text(this.val);
			var successAlertView = new SuccessAlertView({alertMessage:"TODO Assignee Restored and Saved Successfully!"});
			successAlertView.render();
		}
		else{
			var failureAlertView = new FailureAlertView({alertMessage:"No changes applied!"});
			failureAlertView.render();
		}
	},
	handleEditText: function() {
		this.textval = this.$el.find('.textD').text();
		this.$el.find('.textD').attr('contenteditable','true').focus();
	},
	handleSaveText: function() {
		var current = this.$el.find('.textD').text();
		var old = this.textval;
		var attrib = this.$el.find('.textD').attr('contenteditable');
		this.$el.find('.textD').attr('contenteditable','false');
		if(current !== old && attrib === 'true'){
			var successAlertView = new SuccessAlertView({alertMessage:"TODO Text Updated & Saved Successfully!"});
			successAlertView.render();
		}
		else{
			var failureAlertView = new FailureAlertView({alertMessage:"Nothing to Save!"});
			failureAlertView.render();
		}
	},
	handleUndoText:  function() {
		var current = this.$el.find('.textD').text();
		var old = this.textval;
		var attrib = this.$el.find('.textD').attr('contenteditable');
		this.$el.find('.textD').attr('contenteditable','false');
		if(current !== old && attrib === 'true'){
			this.$el.find('.textD').text(this.textval);
			var successAlertView = new SuccessAlertView({alertMessage:"TODO Text Restored and Saved Successfully!"});
			successAlertView.render();
		}
		else{
			var failureAlertView = new FailureAlertView({alertMessage:"No changes applied!"});
			failureAlertView.render();
		}
	},

	handleCompletionStatus: function() {
		var newStatus = this.$el.find('.todoStatus').val();
		if(newStatus === 'Not started'){
			var completionAlertView = new SuccessAlertView({alertMessage:"TODO Status to '"+newStatus+"' Changed Successfully!"});
			completionAlertView.render();
			this.$el.find('.complete').css('display','none');
			this.$el.find('.inProgress').css('display','none');
			this.$el.find('.notStarted').css('display','block');
		}
		if(newStatus === 'In Progress'){
		var completionAlertView = new SuccessAlertView({alertMessage:"TODO Status to '"+newStatus+"' Changed Successfully!"});
			completionAlertView.render();
			this.$el.find('.complete').css('display','none');
			this.$el.find('.inProgress').css('display','block');
			this.$el.find('.notStarted').css('display','none');
		}
		if(newStatus === 'Complete'){
			var completionAlertView = new SuccessAlertView({alertMessage:"TODO Completed Successfully!"});
			completionAlertView.render();
			this.$el.find('.complete').css('display','block');
			this.$el.find('.inProgress').css('display','none');
			this.$el.find('.notStarted').css('display','none');
			this.allCompleteChecker();
		}	
	},
	
	allCompleteChecker: function(){
		var count = 0;
		var completeCount = 0;
		$("#todoList tbody tr").each(function(i,row) {
				count++;
				var x = $(this).find('.complete').css('display');
				if(x === 'block'){
					completeCount++;;	
				}
		});
		if(count === completeCount){
			var completeSuccess = new CompleteSuccess();
			completeSuccess.render();
			$('#myModal').modal('show');
		}
	}
});

var TodoList = Marionette.CompositeView.extend({
	template: require("../templates/todotablelist.html"),
	childView: ToDo,
	childViewContainer: 'tbody'
});

module.exports = TodoList;