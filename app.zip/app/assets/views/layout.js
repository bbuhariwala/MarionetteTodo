var Backbone = require('backbone');
var Marionette = require('backbone.marionette');
var FormView = require('./form');
var ListView = require('./list');
var SuccessAlertView = require('./successAlert');
var FailureAlertView = require('./failureAlert');
var Layout = Marionette.LayoutView.extend({
	el:	"#app-hook",
	template: require("../templates/layout.html"),
	 regions : {
		form: '.form',
		list: '.list'
	 },
	 
	 collectionEvents: {
		add: 'itemAdded'
	 },
	 
	 modelEvents: {
		invalid: 'invalidItem'
	},
	 onShow: function(){
		var formView = new FormView({model: this.model});
		var listView = new ListView({collection: this.collection});
		
		this.showChildView('form',formView);
		this.showChildView('list',listView);
	 },
	 
	 onChildviewAddTodoItem: function(child) {
		this.model.set({
			assignee: child.ui.assignee.val(),
			text: child.ui.text.val()
		});
		
		if(this.model.isValid()){
			var items = this.model.pick('assignee','text');
			this.collection.add(items);
			var successAlertView = new SuccessAlertView({alertMessage:"TODO Added Successfully!"});
			successAlertView.render();
			child.ui.assignee.val('');
			child.ui.text.val('');
		}
	 },
	 
	 itemAdded: function() {
		console.log("itemAdded");
		this.model.set({
			assignee: '',
			text: ''
		});
		
	 },
	 
	  invalidItem: function(errors){
		if(errors.validationError.hasOwnProperty('assignee')){
			var failureAlertView = new FailureAlertView({alertMessage:errors.validationError.assignee});
			failureAlertView.render();
			console.log(errors.validationError.assignee);
		}
		if(errors.validationError.hasOwnProperty('text')) {
			var failureAlertView = new FailureAlertView({alertMessage:errors.validationError.text})
			failureAlertView.render();
			console.log(errors.validationError.text);
		}
	 }
	
});

module.exports = Layout;