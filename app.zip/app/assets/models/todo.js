var Backbone = require('backbone');

var ToDo = Backbone.Model.extend({
	defaults: {
		assignee: '',
		text: ''
	},
	
	validate: function(attrs){
		var errors ={};
		var hasError = false;
		if(!attrs.assignee){
			errors.assignee = 
			hasError = true;
		}
		if(!attrs.text){
			errors.text = 
			hasError = true;
		}
		if (!attrs.assignee.replace(/\s/g, '').length) {
			errors.assignee = "Assignee must be set";
			hasError = true;
		}
		if (!attrs.text.replace(/\s/g, '').length) {
			errors.text = "Text must be set";
			hasError = true;
		}
		
		if(hasError){
			return errors;
		}
	}
});
module.exports = ToDo;